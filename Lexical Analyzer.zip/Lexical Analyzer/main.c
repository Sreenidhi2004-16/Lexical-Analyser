//----------------Documentation----------------//
/*Name:Sreenidhi B S
  Project Name:Lexical Analyzer    
  Description:Implementation of Lexical Analyzer
*/


#include "lexer.h"

int main(int argc, char *argv[])
{
    FILE *fp;

    // Check whether the source file name is provided
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <source_file.c>\n", argv[0]);
        return 1;
    }

    // Open the source file in read mode
    fp = fopen(argv[1], "r");

    // Check whether the file was opened successfully
    if (fp == NULL) {
        perror("Error opening source file");
        return 1;
    }

    // Display the output table heading
    printf("%-30s : %s\n", "TOKEN", "TOKEN TYPE");
    printf("--------------------------------------------------\n");

    // Call the lexical analyzer to identify and classify tokens
    analyzeFile(fp);

    // Close the source file
    fclose(fp);

    // Indicate successful program execution
    return 0;
}

