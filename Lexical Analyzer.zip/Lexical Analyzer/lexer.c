#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include "lexer.h"

/* C keywords */
static const char *keywords[] = {
    "auto", "break", "case", "char", "const", "continue",
    "default", "do", "double", "else", "enum", "extern",
    "float", "for", "goto", "if", "int", "long", "register",
    "return", "short", "signed", "sizeof", "static", "struct",
    "switch", "typedef", "union", "unsigned", "void", "volatile",
    "while", "_Alignas", "_Alignof", "_Atomic", "_Bool",
    "_Complex", "_Generic", "_Imaginary", "_Noreturn",
    "_Static_assert", "_Thread_local"
};

/* Check whether a token is a keyword */
static int isKeyword(const char *token)
{
    size_t count = sizeof(keywords) / sizeof(keywords[0]);

    for (size_t i = 0; i < count; i++)
    {
        if (strcmp(token, keywords[i]) == 0)
            return 1;
    }

    return 0;
}

/* Print token and token type */
static void printToken(const char *token, const char *type)
{
    printf("%-30s : %s\n", token, type);
}

/* Check whether a character is an operator */
static int isOperatorChar(int ch)
{
    return ch != EOF &&
           strchr("+-*/%=<>!&|^~?:", ch) != NULL;
}

/* Check whether a character is a special symbol */
static int isSpecialSymbol(int ch)
{
    return ch != EOF &&
           strchr("(){}[];,.", ch) != NULL;
}

/* Read a token without overflowing the buffer */
static void appendChar(char *buffer, size_t capacity,
                       size_t *length, int ch)
{
    if (*length + 1 < capacity)
    {
        buffer[*length] = (char)ch;
        (*length)++;
    }
}

/* Read a preprocessor directive, including backslash continuations */
static void readPreprocessorDirective(FILE *fp)
{
    char buffer[2048];
    size_t length = 0;
    int ch;
    int previous = 0;

    appendChar(buffer, sizeof(buffer), &length, '#');

    while ((ch = fgetc(fp)) != EOF)
    {
        if (ch == '\n')
        {
            /* Continue if the line ends with a backslash */
            if (previous == '\\')
            {
                appendChar(buffer, sizeof(buffer), &length, ch);
                previous = 0;
                continue;
            }

            break;
        }

        appendChar(buffer, sizeof(buffer), &length, ch);
        previous = ch;
    }

    buffer[length] = '\0';
    printToken(buffer, "PREPROCESSOR DIRECTIVE");
}

/* Read a single-line comment */
static void readSingleLineComment(FILE *fp)
{
    char buffer[2048];
    size_t length = 0;
    int ch;

    appendChar(buffer, sizeof(buffer), &length, '/');
    appendChar(buffer, sizeof(buffer), &length, '/');

    while ((ch = fgetc(fp)) != EOF && ch != '\n')
        appendChar(buffer, sizeof(buffer), &length, ch);

    buffer[length] = '\0';
    printToken(buffer, "SINGLE-LINE COMMENT");
}

/* Read a multi-line comment */
static void readMultiLineComment(FILE *fp)
{
    char buffer[4096];
    size_t length = 0;
    int ch;
    int previous = 0;

    appendChar(buffer, sizeof(buffer), &length, '/');
    appendChar(buffer, sizeof(buffer), &length, '*');

    while ((ch = fgetc(fp)) != EOF)
    {
        appendChar(buffer, sizeof(buffer), &length, ch);

        if (previous == '*' && ch == '/')
            break;

        previous = ch;
    }

    buffer[length] = '\0';
    printToken(buffer, "MULTI-LINE COMMENT");
}

/* Read a string or character literal */
static void readQuotedLiteral(FILE *fp, int quote, const char *type)
{
    char buffer[2048];
    size_t length = 0;
    int ch;
    int escaped = 0;

    appendChar(buffer, sizeof(buffer), &length, quote);

    while ((ch = fgetc(fp)) != EOF)
    {
        appendChar(buffer, sizeof(buffer), &length, ch);

        if (ch == quote && !escaped)
            break;

        if (ch == '\\' && !escaped)
            escaped = 1;
        else
            escaped = 0;

        /* Stop at an unescaped newline in an invalid literal */
        if (ch == '\n' && !escaped)
            break;
    }

    buffer[length] = '\0';
    printToken(buffer, type);
}

/* Recognize common C numeric constants */
static void readNumber(FILE *fp, int first)
{
    char buffer[256];
    size_t length = 0;
    int ch;
    int isFloat = 0;
    int isHex = 0;
    int isBinary = 0;

    appendChar(buffer, sizeof(buffer), &length, first);

    if (first == '0')
    {
        ch = fgetc(fp);

        if (ch == 'x' || ch == 'X')
        {
            appendChar(buffer, sizeof(buffer), &length, ch);
            isHex = 1;
        }
        else if (ch == 'b' || ch == 'B')
        {
            appendChar(buffer, sizeof(buffer), &length, ch);
            isBinary = 1;
        }
        else if (ch != EOF)
        {
            ungetc(ch, fp);
        }
    }

    while ((ch = fgetc(fp)) != EOF)
    {
        int valid = 0;

        if (isHex)
        {
            valid = isxdigit((unsigned char)ch);
        }
        else if (isBinary)
        {
            valid = (ch == '0' || ch == '1');
        }
        else
        {
            valid = isdigit((unsigned char)ch);

            if (ch == '.' && !isFloat)
            {
                isFloat = 1;
                valid = 1;
            }

            if ((ch == 'e' || ch == 'E') && !isHex)
            {
                isFloat = 1;
                valid = 1;

                appendChar(buffer, sizeof(buffer), &length, ch);

                ch = fgetc(fp);

                if (ch == '+' || ch == '-')
                {
                    appendChar(buffer, sizeof(buffer), &length, ch);
                    continue;
                }

                if (ch != EOF)
                    ungetc(ch, fp);

                continue;
            }
        }

        if (valid)
        {
            appendChar(buffer, sizeof(buffer), &length, ch);
        }
        else if (ch == 'u' || ch == 'U' ||
                 ch == 'l' || ch == 'L' ||
                 ch == 'f' || ch == 'F')
        {
            appendChar(buffer, sizeof(buffer), &length, ch);
        }
        else
        {
            ungetc(ch, fp);
            break;
        }
    }

    buffer[length] = '\0';

    if (isFloat)
        printToken(buffer, "FLOAT CONSTANT");
    else
        printToken(buffer, "INTEGER CONSTANT");
}

/* Read an operator, including common multi-character operators */
static void readOperator(FILE *fp, int first)
{
    char token[4] = {(char)first, '\0', '\0', '\0'};
    int second = fgetc(fp);
    int third = EOF;

    if (second == '=' ||
        ((first == '+' || first == '-') && second == first) ||
        (first == '&' && second == '&') ||
        (first == '|' && second == '|') ||
        ((first == '<' || first == '>') && second == first))
    {
        token[1] = (char)second;

        if ((first == '<' || first == '>') && second == first)
        {
            third = fgetc(fp);

            if (third == '=')
                token[2] = '=';
            else if (third != EOF)
                ungetc(third, fp);
        }
    }
    else if (second != EOF)
    {
        ungetc(second, fp);
    }

    printToken(token, "OPERATOR");
}

/* Main lexical analyzer */
void analyzeFile(FILE *fp)
{
    int ch;
    int atLineStart = 1;

    while ((ch = fgetc(fp)) != EOF)
    {
        /* Newline */
        if (ch == '\n')
        {
            atLineStart = 1;
            continue;
        }

        /* Ignore whitespace but preserve line-start state */
        if (isspace((unsigned char)ch))
            continue;

        /* Preprocessor directives must start at the beginning
           of a logical line, allowing leading spaces */
        if (ch == '#' && atLineStart)
        {
            readPreprocessorDirective(fp);
            atLineStart = 1;
            continue;
        }

        atLineStart = 0;

        /* Identifiers and keywords */
        if (isalpha((unsigned char)ch) || ch == '_')
        {
            char token[256];
            size_t length = 0;

            appendChar(token, sizeof(token), &length, ch);

            while ((ch = fgetc(fp)) != EOF &&
                   (isalnum((unsigned char)ch) || ch == '_'))
            {
                appendChar(token, sizeof(token), &length, ch);
            }

            token[length] = '\0';

            if (ch != EOF)
                ungetc(ch, fp);

            printToken(token, isKeyword(token) ?
                       "KEYWORD" : "IDENTIFIER");
        }

        /* Integer and floating-point constants */
        else if (isdigit((unsigned char)ch))
        {
            readNumber(fp, ch);
        }

        /* String literals */
        else if (ch == '"')
        {
            readQuotedLiteral(fp, '"', "STRING LITERAL");
        }

        /* Character constants */
        else if (ch == '\'')
        {
            readQuotedLiteral(fp, '\'', "CHARACTER CONSTANT");
        }

        /* Comments or division operator */
        else if (ch == '/')
        {
            int next = fgetc(fp);

            if (next == '/')
                readSingleLineComment(fp);
            else if (next == '*')
                readMultiLineComment(fp);
            else
            {
                if (next != EOF)
                    ungetc(next, fp);

                printToken("/", "OPERATOR");
            }
        }

        /* Operators */
        else if (isOperatorChar(ch))
        {
            readOperator(fp, ch);
        }

        /* Special symbols */
        else if (isSpecialSymbol(ch))
        {
            char token[2] = {(char)ch, '\0'};
            printToken(token, "SPECIAL SYMBOL");
        }

        /* Unrecognized characters */
        else
        {
            char token[2] = {(char)ch, '\0'};
            printToken(token, "UNKNOWN TOKEN");
        }
    }
}

